Module 1: Narrow-band DoA estimation
Module 2: Broadband DoA estimation
Module 3: Microphone array experiment
Module 4:Bonus.mlapp